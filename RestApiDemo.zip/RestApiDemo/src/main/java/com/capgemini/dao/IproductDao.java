package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Product;

public interface IproductDao {
	
	public List<Product> getAllProducts();
	public List<Product> removeProduct(int productId);
	public List<Product> addnewProduct(int productId,String productName);
	public Product getProduct(int productId);
	public  List<Product> updateProduct(Product product);

}
