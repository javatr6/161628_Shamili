package com.capgemini.demo;

import javax.persistence.Entity;

@Entity
public class module extends Project{

private String moduleName;

public module() {
	
}
public module(String moduleName) {
	super();
	this.moduleName = moduleName;
}

public String getModuleName() {
	return moduleName;
}

public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}

@Override
public String toString() {
	return "module [moduleName=" + moduleName + "]";
}

}
