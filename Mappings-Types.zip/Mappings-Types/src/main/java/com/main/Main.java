package com.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
			transaction.begin(); 
			Events java=new Events();
			java.setEventId("101-JAVA");
			java.setEventName("JAVA");
			
			Events or=new Events();
			or.setEventId("456-Oracle");
			or.setEventName("JAVA");
			
			Delegates ram=new Delegates(1,"ram");
			ram.getEvents().add(or);
			Delegates sita=new Delegates(2,"sita");
			sita.getEvents().add(java);
			entityManager.persist(java);
			entityManager.persist(or);
			entityManager.persist(ram);
			
			
			transaction.commit();
			entityManager.close();

	}

}
