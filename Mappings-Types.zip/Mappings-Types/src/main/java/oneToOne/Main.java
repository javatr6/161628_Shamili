package oneToOne;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();
		
		Customer shamili= new Customer("shamili","adhikara",15600);
		Address address= new Address(1001,"Pg- near Petrol Bunk",LocalDate.now(),shamili);
		em.persist(shamili);
		em.persist(address);
		transaction.commit();
		em.close();
	}
}
