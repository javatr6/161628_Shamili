package registration;  


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver driver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\shaadhik\\Desktop\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	@Given("^open buspass registration page$")
	public void open_buspass_registration_page() throws Throwable {
		driver.get("http://localhost:8081/BusPassRequest/pages/requestform.html?");
		String title=driver.getTitle();
		assertEquals("Insert title here",title);
		Thread.sleep(3000);
	    
	}

	@Given("^details of the user$")
	public void details_of_the_user() throws Throwable {
		
		driver.findElement(By.name("empid")).sendKeys("161628");
		driver.findElement(By.name("fname")).sendKeys("Shamili");
		driver.findElement(By.name("lname")).sendKeys("Adhikara");
		driver.findElement(By.name("emailid")).sendKeys("Sham@gmail.com");
		WebElement radio=driver.findElement(By.id("female"));
		radio.click();
		Select designation=new Select(driver.findElement(By.name("designation")));
		designation.selectByVisibleText("Software Engineer");
		driver.findElement(By.name("address")).sendKeys("Hyderabad");
		driver.findElement(By.name("doj")).sendKeys("05122018");
		Select location=new Select(driver.findElement(By.name("location")));
		location.selectByVisibleText("Chennai MIPL");
		Select pickuploc=new Select(driver.findElement(By.name("pickuplocation")));
		pickuploc.selectByVisibleText("Tambaram");
		driver.findElement(By.name("pickuptime")).sendKeys("0900PM");
		Thread.sleep(5000);
	    
	}

	@When("^submit after details entered$")
	public void submit_after_details_entered() throws Throwable {
		WebElement login=driver.findElement(By.name("submit"));
		login.submit();
		Thread.sleep(3000);
	    
	}

	@Then("^redirect to successfulpage$")
	public void redirect_to_successfulpage() throws Throwable {
		driver.navigate().to("http://localhost:8081/BusPassRequest/pages/request.html");
	    
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}

} 
 
