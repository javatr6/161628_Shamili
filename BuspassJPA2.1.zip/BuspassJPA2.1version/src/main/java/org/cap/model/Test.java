package org.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("PERSISTENCE");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Routetable routetable=new Routetable();
		routetable.setRoute_path("ChennaiMIPL,Tambaram,Parnur");
		routetable.setNo_of_seats_occupied(10);
		routetable.setTotal_seats(45);
		routetable.setBus_no("1A");
		routetable.setDriver_name("Man");
		routetable.setTotal_km(45.0);
		LoginBean loginBean=new LoginBean("sham", "sham123");
		LoginBean loginBean1=new LoginBean("Sam", "Sam123");
		LoginBean loginBean2=new LoginBean("Don", "Don");
		LoginBean loginBean3=new LoginBean("bean", "bean123");
		
		entityManager.persist(routetable);
		entityManager.persist(loginBean);
		entityManager.persist(loginBean1);
		entityManager.persist(loginBean2);
		entityManager.persist(loginBean3);
		transaction.commit();
		entityManager.close();
	}

}
