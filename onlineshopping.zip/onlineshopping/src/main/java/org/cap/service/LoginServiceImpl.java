package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	private ILoginDao dao=null;
	public LoginServiceImpl() {
		this.dao=new LoginDaoImpl();
	}
	@Override
	public boolean isValidLogin(LoginBean bean) {
		if(dao.isValidLogin(bean))
			return true;
		return false;
	}

}
